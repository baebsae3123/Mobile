package com.cookandroid.myapplication2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        Intent intent = getIntent();
        int[] voteResult = intent.getIntArrayExtra("VoteCount");
        String[] imageName = intent.getStringArrayExtra("ImageName");
        //textView
        TextView[] tv = new TextView[imageName.length];
        //rateinbar
        RatingBar[] rbr = new RatingBar [imageName.length];

        Integer tvID[] = {R.id.iv1,R.id.iv2,R.id.iv3,
                R.id.iv4,R.id.iv5,R.id.iv6,
                R.id.iv7,R.id.iv8,R.id.iv9};

        Integer rbrID[] = {R.id.iv1,R.id.iv2,R.id.iv3,
                R.id.iv4,R.id.iv5,R.id.iv6,
                R.id.iv7,R.id.iv8,R.id.iv9};

        for(int i=0; i<voteResult.length;i++){
            tv[i] = (TextView) findViewById(tvID[i]);
            rbr[i] = (RatingBar) findViewById(rbrID[i]);
        }
        for(int i=0; i<voteResult.length; i++){
            tv[i].setText(imageName[i]);
            rbr[i].setRating(voteResult[i]);

        }
        Button btnReturn = (Button) findViewById(R.id.btnReturn);

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}
