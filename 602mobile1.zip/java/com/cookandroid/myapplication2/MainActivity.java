package com.cookandroid.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("명화 선호도 투표");

        final int voteCount[] = new int[9];
        for(int i=0;i<9;i++){
            voteCount[i]=0;
        }
        //
        ImageView image[] = new ImageView[9];

        Integer ImageID[] = {R.id.iv1,R.id.iv2,R.id.iv3,
                R.id.iv4,R.id.iv5,R.id.iv6,
                R.id.iv7,R.id.iv8,R.id.iv9};
        final String imgName[] = {"독서하는소녀" ,"꽃장식 모자소녀","부채를 든소녀",
                "이레강 든소녀","잠자는 소녀","피아노 든소녀",
                "테라슨 든소녀","피아노앞 든소녀","해변에서 든소녀",};

        for(int i=0; i<ImageID.length;i++){
            final int index;
            index = i;

            //할당
            image[index]= (ImageView) findViewById(ImageID[index]);

            image[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    voteCount[index]++;
                    Toast.makeText(MainActivity.this,imgName[index]+": 총 "+voteCount[index]+"표",Toast.LENGTH_SHORT).show();
                }
            });
        }

        Button btnFinsh = (Button) findViewById(R.id.btnResult);

        btnFinsh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this ,ResultActivity.class);
                intent.putExtra("VoteCount",voteCount);
                intent.putExtra("ImageName",imgName);
                startActivity(intent);

            }
        });


    }
}