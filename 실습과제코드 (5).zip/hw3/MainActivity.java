package com.cookandroid.w12_hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class MainActivity extends AppCompatActivity {

    // ViewFlipper : 여러 안내 화면을 한 장씩 보여주는 뷰 컨테이너
    ViewFlipper viewFlipperGuide;

    // SeekBar : 자동 전환 속도 조절
    SeekBar seekBarSpeed;

    // ProgressBar : 현재 슬라이드 번호 표시
    ProgressBar progressSlide;

    // TextView : 현재 화면 번호, 속도, 상태 메시지 출력
    TextView tvSlideNumber, tvSpeed, tvStatus;

    // Button : 이전, 다음, 자동 시작, 자동 정지
    Button btnPrev, btnNext, btnAutoStart, btnAutoStop;

    // 전체 슬라이드 개수
    final int TOTAL_SLIDE_COUNT = 4;

    // 자동 전환 속도, 기본값 2초
    int flipSecond = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // activity_main.xml 화면을 현재 Activity에 연결
        setContentView(R.layout.activity_main);

        // XML 위젯과 Java 변수 연결
        viewFlipperGuide = (ViewFlipper) findViewById(R.id.viewFlipperGuide);
        seekBarSpeed = (SeekBar) findViewById(R.id.seekBarSpeed);
        progressSlide = (ProgressBar) findViewById(R.id.progressSlide);

        tvSlideNumber = (TextView) findViewById(R.id.tvSlideNumber);
        tvSpeed = (TextView) findViewById(R.id.tvSpeed);
        tvStatus = (TextView) findViewById(R.id.tvStatus);

        btnPrev = (Button) findViewById(R.id.btnPrev);
        btnNext = (Button) findViewById(R.id.btnNext);
        btnAutoStart = (Button) findViewById(R.id.btnAutoStart);
        btnAutoStop = (Button) findViewById(R.id.btnAutoStop);

        /*
            ProgressBar 설정
            전체 슬라이드가 4장이므로 max를 4로 설정
        */
        progressSlide.setMax(TOTAL_SLIDE_COUNT);
        progressSlide.setProgress(1);

        /*
            SeekBar 설정

            SeekBar 값은 0~4까지 사용
            실제 자동 전환 속도는 1~5초로 변환

            progress 0 → 1초
            progress 1 → 2초
            progress 2 → 3초
            progress 3 → 4초
            progress 4 → 5초
        */
        seekBarSpeed.setMax(4);
        seekBarSpeed.setProgress(1);

        // 기본 자동 전환 시간 설정
        viewFlipperGuide.setFlipInterval(flipSecond * 1000);

        /*
            슬라이드 전환 애니메이션 설정

            Handler나 Runnable 없이도
            AnimationListener를 이용하면 슬라이드가 전환된 뒤
            현재 화면 번호와 ProgressBar를 갱신할 수 있음
        */
        setSlideAnimation();

        // 초기 화면 정보 출력
        updateSlideInfo();
        tvSpeed.setText("자동 전환 속도 : " + flipSecond + "초");

        /*
            이전 버튼 클릭 이벤트

            showPrevious()
            → ViewFlipper 안에 있는 이전 View를 화면에 보여줌
        */
        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipperGuide.showPrevious();
                updateSlideInfo();
                tvStatus.setText("이전 안내 화면으로 이동했습니다.");
            }
        });

        /*
            다음 버튼 클릭 이벤트

            showNext()
            → ViewFlipper 안에 있는 다음 View를 화면에 보여줌
        */
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipperGuide.showNext();
                updateSlideInfo();
                tvStatus.setText("다음 안내 화면으로 이동했습니다.");
            }
        });

        /*
            자동 시작 버튼 클릭 이벤트

            startFlipping()
            → setFlipInterval()로 설정한 시간 간격에 따라
              ViewFlipper가 자동으로 다음 화면을 보여줌
        */
        btnAutoStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 이미 자동 실행 중이면 중복 실행하지 않음
                if (!viewFlipperGuide.isFlipping()) {

                    // 현재 SeekBar 값 기준으로 전환 시간 설정
                    viewFlipperGuide.setFlipInterval(flipSecond * 1000);

                    // 자동 전환 시작
                    viewFlipperGuide.startFlipping();

                    tvStatus.setText("자동 슬라이드가 시작되었습니다.");
                    Toast.makeText(MainActivity.this, "자동 시작", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "이미 자동 실행 중입니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*
            자동 정지 버튼 클릭 이벤트

            stopFlipping()
            → 자동 슬라이드 전환을 정지함
        */
        btnAutoStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 자동 전환 정지
                viewFlipperGuide.stopFlipping();

                // 정지한 시점의 현재 화면 번호 갱신
                updateSlideInfo();

                tvStatus.setText("자동 슬라이드가 정지되었습니다.");
                Toast.makeText(MainActivity.this, "자동 정지", Toast.LENGTH_SHORT).show();
            }
        });

        /*
            SeekBar 값 변경 이벤트

            사용자가 SeekBar를 움직이면 자동 전환 속도가 변경됨
        */
        seekBarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            // SeekBar 값이 바뀔 때마다 실행됨
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                // progress 0~4를 실제 속도 1~5초로 변환
                flipSecond = progress + 1;

                // 자동 전환 속도 출력
                tvSpeed.setText("자동 전환 속도 : " + flipSecond + "초");

                // ViewFlipper 자동 전환 간격 변경
                viewFlipperGuide.setFlipInterval(flipSecond * 1000);

                // 자동 실행 중일 때 상태 문구 출력
                if (viewFlipperGuide.isFlipping()) {
                    tvStatus.setText("자동 전환 속도가 " + flipSecond + "초로 변경되었습니다.");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // 이 실습에서는 사용하지 않음
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // 이 실습에서는 사용하지 않음
            }
        });
    }

    /*
        ViewFlipper 전환 애니메이션을 설정하는 메소드

        자동 전환 중에도 화면 번호와 ProgressBar를 갱신하기 위해
        inAnimation에 AnimationListener를 연결함

        Thread, Handler, Runnable은 사용하지 않음
    */
    private void setSlideAnimation() {

        // 안드로이드에서 제공하는 기본 슬라이드 애니메이션 사용
        Animation inAnim = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        Animation outAnim = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);

        /*
            inAnim이 끝났을 때 현재 화면 정보를 갱신함
            자동 전환이든 수동 전환이든 슬라이드가 넘어가면 실행됨
        */
        inAnim.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {
                // 애니메이션 시작 시에는 별도 처리 없음
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // 슬라이드 전환이 끝난 후 현재 화면 번호 갱신
                updateSlideInfo();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // 반복 애니메이션을 사용하지 않으므로 처리 없음
            }
        });

        // ViewFlipper에 애니메이션 적용
        viewFlipperGuide.setInAnimation(inAnim);
        viewFlipperGuide.setOutAnimation(outAnim);
    }

    /*
        현재 슬라이드 번호와 ProgressBar를 갱신하는 메소드
    */
    private void updateSlideInfo() {

        /*
            getDisplayedChild()
            → 현재 ViewFlipper가 보여주고 있는 자식 View의 번호를 가져옴
            → 번호는 0부터 시작함

            예)
            첫 번째 화면 → 0
            두 번째 화면 → 1
            세 번째 화면 → 2
            네 번째 화면 → 3
        */
        int currentIndex = viewFlipperGuide.getDisplayedChild();

        // 사용자에게 보여줄 번호는 1부터 시작하도록 +1
        int currentSlideNumber = currentIndex + 1;

        // 현재 화면 번호 출력
        tvSlideNumber.setText("현재 화면 : " + currentSlideNumber + " / " + TOTAL_SLIDE_COUNT);

        // ProgressBar 진행 상태 변경
        progressSlide.setProgress(currentSlideNumber);
    }

    /*
        Activity가 종료될 때 실행됨
        앱이 종료될 때 자동 슬라이드를 정지함
    */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // 자동 전환 정지
        viewFlipperGuide.stopFlipping();
    }
}