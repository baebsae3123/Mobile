package com.cookandroid.w12_hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // 여행지 자동완성 입력 위젯
    AutoCompleteTextView autoCity;

    // 준비물 여러 개 자동완성 입력 위젯
    MultiAutoCompleteTextView multiItems;

    // 날짜 선택 위젯
    DatePicker datePickerTravel;

    // 여행 기대도 별점 위젯
    RatingBar ratingTravel;

    // 결과 출력 TextView
    TextView tvResult;

    // 버튼
    Button btnSave, btnReset;

    // 여행지 자동완성에 사용할 데이터
    String[] cityList = {
            "서울", "부산", "제주", "강릉", "전주",
            "여수", "경주", "속초", "대전", "대구",
            "인천", "춘천", "통영", "포항", "목포"
    };

    // 준비물 자동완성에 사용할 데이터
    String[] itemList = {
            "충전기", "보조배터리", "세면도구", "우산", "카메라",
            "수건", "이어폰", "상비약", "선글라스", "모자",
            "여권", "지갑", "운동화", "물티슈", "간식"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // activity_main.xml 화면을 현재 Activity에 연결
        setContentView(R.layout.activity_main);

        // XML 위젯과 Java 변수 연결
        autoCity = findViewById(R.id.autoCity);
        multiItems = findViewById(R.id.multiItems);
        datePickerTravel = findViewById(R.id.datePickerTravel);
        ratingTravel = findViewById(R.id.ratingTravel);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        btnReset = findViewById(R.id.btnReset);

        /*
            ArrayAdapter 생성

            ArrayAdapter는 문자열 배열 데이터를
            AutoCompleteTextView 또는 MultiAutoCompleteTextView에 연결하는 역할을 함

            android.R.layout.simple_dropdown_item_1line:
            자동완성 목록을 한 줄짜리 기본 형태로 보여주는 안드로이드 기본 레이아웃
        */
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                cityList
        );

        ArrayAdapter<String> itemAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                itemList
        );

        /*
            AutoCompleteTextView에 여행지 어댑터 연결
            사용자가 글자를 입력하면 cityList에서 일치하는 항목을 추천함
        */
        autoCity.setAdapter(cityAdapter);

        /*
            몇 글자부터 자동완성 목록을 보여줄지 설정
            1이면 한 글자만 입력해도 자동완성 목록이 나타남
        */
        autoCity.setThreshold(1);

        /*
            MultiAutoCompleteTextView에 준비물 어댑터 연결
            여러 준비물을 자동완성으로 입력할 수 있음
        */
        multiItems.setAdapter(itemAdapter);
        multiItems.setThreshold(1);

        /*
            CommaTokenizer 설정

            MultiAutoCompleteTextView는 토크나이저를 설정해야
            쉼표(,)를 기준으로 여러 단어를 자동완성할 수 있음

            예)
            충전기, 우산, 카메라
        */
        multiItems.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        /*
            계획 저장 버튼 클릭 이벤트
            사용자가 입력한 여행지, 준비물, 날짜, 별점을 가져와서 결과 TextView에 출력
        */
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveTravelPlan();
            }
        });

        /*
            초기화 버튼 클릭 이벤트
            입력값과 결과 화면을 초기 상태로 되돌림
        */
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTravelPlan();
            }
        });
    }

    /*
        여행 계획 저장 메소드
    */
    private void saveTravelPlan() {

        // AutoCompleteTextView에서 여행지 입력값 가져오기
        String city = autoCity.getText().toString().trim();

        // MultiAutoCompleteTextView에서 준비물 입력값 가져오기
        String items = multiItems.getText().toString().trim();

        /*
            DatePicker에서 날짜 값 가져오기

            getYear()       : 선택한 연도
            getMonth()      : 선택한 월, 단 0부터 시작함
                              0 = 1월, 1 = 2월, 11 = 12월
            getDayOfMonth() : 선택한 일
        */
        int year = datePickerTravel.getYear();
        int month = datePickerTravel.getMonth() + 1;
        int day = datePickerTravel.getDayOfMonth();

        // RatingBar에서 별점 값 가져오기
        float rating = ratingTravel.getRating();

        /*
            입력값 검사
            여행지를 입력하지 않은 경우 저장하지 않고 안내 메시지 출력
        */
        if (city.length() == 0) {
            Toast.makeText(this, "여행지를 입력하세요.", Toast.LENGTH_SHORT).show();
            autoCity.requestFocus();
            return;
        }

        /*
            준비물을 입력하지 않은 경우 저장하지 않고 안내 메시지 출력
        */
        if (items.length() == 0) {
            Toast.makeText(this, "준비물을 입력하세요.", Toast.LENGTH_SHORT).show();
            multiItems.requestFocus();
            return;
        }

        // 결과 문자열 만들기
        String result = "";
        result += "여행지 : " + city + "\n";
        result += "여행 날짜 : " + year + "년 " + month + "월 " + day + "일\n";
        result += "준비물 : " + items + "\n";
        result += "기대도 : " + rating + "점\n";

        /*
            별점이 4점 이상이면 추가 메시지 출력
        */
        if (rating >= 4.0) {
            result += "\n기대되는 여행입니다!";
        } else if (rating >= 2.5) {
            result += "\n무난한 여행 계획입니다.";
        } else {
            result += "\n조금 더 준비하면 좋겠습니다.";
        }

        // 결과 TextView에 출력
        tvResult.setText(result);

        // 저장 완료 Toast 메시지 출력
        Toast.makeText(this, "여행 계획이 저장되었습니다.", Toast.LENGTH_SHORT).show();
    }

    /*
        여행 계획 초기화 메소드
    */
    private void resetTravelPlan() {

        // 여행지 입력값 초기화
        autoCity.setText("");

        // 준비물 입력값 초기화
        multiItems.setText("");

        // 별점 기본값으로 초기화
        ratingTravel.setRating(3);

        // 결과 TextView 초기화
        tvResult.setText("아직 저장된 여행 계획이 없습니다.");

        // 여행지 입력칸에 포커스 이동
        autoCity.requestFocus();

        // 초기화 안내 메시지 출력
        Toast.makeText(this, "입력 내용이 초기화되었습니다.", Toast.LENGTH_SHORT).show();
    }
}