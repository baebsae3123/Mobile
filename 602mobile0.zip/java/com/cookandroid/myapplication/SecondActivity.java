package com.cookandroid.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.cookandroid.myapplication.R;

public class SecondActivity extends Activity
{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second);
        Button btnReturn = (Button) findViewById(R.id.btnReturn1);
        Button btnNew = (Button) findViewById(R.id.btnNew);

        RadioButton rdoThrid= (RadioButton) findViewById(R.id.rdoThird);
        RadioButton rdoFourth = (RadioButton) findViewById(R.id.rdoFouth);

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //thrid 및 Fourthintent  액티비티 객체 생성

                Intent Thridintent = new Intent(SecondActivity.this, ThridACtivity.class); //액티비티 표시 --> secondActivity 로 이동

                Intent Fourthintent = new Intent(SecondActivity.this, FourthActivity.class); //액티비티 표시 --> secondActivity 로 이동

                if(rdoThrid.isChecked()){
                    //thrid 액티비티 이동
                    startActivity(Thridintent); //secondActivity로 이동

                }else{
                    //fourth 액티비티 이동
                    startActivity(Fourthintent); //secondActivity로 이동
                }


            }
        });

    }
}
